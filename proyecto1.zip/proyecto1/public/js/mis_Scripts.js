

$(function () {

	setTimeout(function () {
        $(".du").fadeOut(1500);
    }, 3000);

 setTimeout(function () {
        $(".re").fadeOut(1500);
    }, 3000);
 
});
